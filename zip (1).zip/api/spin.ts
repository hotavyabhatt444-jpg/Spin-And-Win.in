import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }
  
  const { betAmount } = req.body;
  
  const validBets = [10, 40, 100, 1000];
  if (!validBets.includes(betAmount)) {
    return res.status(400).json({ error: "Invalid bet amount" });
  }

  // 30% chance of winning, 70% chance of losing
  const isWin = Math.random() < 0.30;
  let winAmount = 0;

  if (isWin) {
    switch (betAmount) {
      case 10: winAmount = 10 * 3; break;
      case 40: winAmount = 40 * 7; break;
      case 100: winAmount = 100 * 10; break;
      case 1000: winAmount = 1000 * 100; break;
    }
  }

  return res.status(200).json({ winAmount });
}
