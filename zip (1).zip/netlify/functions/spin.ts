import { Handler } from '@netlify/functions';

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  
  try {
    const { betAmount } = JSON.parse(event.body || '{}');
    
    const validBets = [10, 40, 100, 1000];
    if (!validBets.includes(betAmount)) {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid bet amount" }) };
    }

    // 30% chance of winning, 70% chance of losing
    const isWin = Math.random() < 0.30;
    let winAmount = 0;

    if (isWin) {
      switch (betAmount) {
        case 10: winAmount = 10 * 3; break;
        case 40: winAmount = 40 * 7; break;
        case 100: winAmount = 100 * 10; break;
        case 1000: winAmount = 1000 * 100; break;
      }
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ winAmount })
    };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: "Internal Server Error" }) };
  }
};
