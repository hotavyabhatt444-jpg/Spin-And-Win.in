import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "./lib/firebase";
import { doc, getDoc, onSnapshot } from "firebase/firestore";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import Wallet from "./pages/Wallet";
import Withdraw from "./pages/Withdraw";
import Referral from "./pages/Referral";
import Admin from "./pages/Admin";
import Auth from "./pages/Auth";
import { Coins, LayoutDashboard, Wallet as WalletIcon, ArrowDownToLine, Users, ShieldAlert, LogOut } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let unsubUserDoc: () => void;

    const checkLocalUser = () => {
      const storedUid = localStorage.getItem("local_uid");
      const storedEmail = localStorage.getItem("local_email");
      
      if (storedUid && storedEmail) {
        setLoading(true);
        const currentUser = { uid: storedUid, email: storedEmail };
        setUser(currentUser);
        
        unsubUserDoc = onSnapshot(doc(db, "users", storedUid), (docSnap) => {
          if (docSnap.exists()) {
            setIsAdmin(docSnap.data().role === "admin");
          } else {
            setIsAdmin(false);
          }
          setLoading(false);
        });
      } else {
        setUser(null);
        setIsAdmin(false);
        setLoading(false);
        if (unsubUserDoc) unsubUserDoc();
      }
    };

    checkLocalUser();
    
    window.addEventListener('local-login', checkLocalUser);
    
    const handleLogout = () => {
      localStorage.removeItem("local_uid");
      localStorage.removeItem("local_email");
      checkLocalUser();
    };
    window.addEventListener('local-logout', handleLogout);

    return () => {
      window.removeEventListener('local-login', checkLocalUser);
      window.removeEventListener('local-logout', handleLogout);
      if (unsubUserDoc) unsubUserDoc();
    };
  }, []);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-background text-white">Loading...</div>;
  }

  return (
    <Router>
      <div className="min-h-screen bg-background text-white flex flex-col">
        <nav className="border-b border-white/10 bg-black/50 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link to="/" className="flex items-center gap-2">
                <Coins className="h-8 w-8 text-primary animate-pulse" />
                <span className="font-bold text-xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-primary to-highlight-blue">SPIN & WIN</span>
              </Link>
              
              {user && (
                <div className="hidden md:flex items-center gap-6">
                  <Link to="/dashboard" className="flex items-center gap-2 hover:text-primary transition-colors"><LayoutDashboard size={18}/> Dashboard</Link>
                  <Link to="/wallet" className="flex items-center gap-2 hover:text-primary transition-colors"><WalletIcon size={18}/> Wallet</Link>
                  <Link to="/withdraw" className="flex items-center gap-2 hover:text-primary transition-colors"><ArrowDownToLine size={18}/> Withdraw</Link>
                  <Link to="/referral" className="flex items-center gap-2 hover:text-primary transition-colors"><Users size={18}/> Refer & Earn</Link>
                  {isAdmin && <Link to="/admin" className="flex items-center gap-2 text-red-400 hover:text-red-300 transition-colors"><ShieldAlert size={18}/> Admin</Link>}
                  <button onClick={() => window.dispatchEvent(new Event('local-logout'))} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors ml-4"><LogOut size={18}/> Logout</button>
                </div>
              )}
            </div>
          </div>
        </nav>

        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Landing user={user} />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/dashboard" element={<Dashboard user={user} />} />
            <Route path="/wallet" element={<Wallet user={user} />} />
            <Route path="/withdraw" element={<Withdraw user={user} />} />
            <Route path="/referral" element={<Referral user={user} />} />
            <Route path="/admin" element={<Admin user={user} isAdmin={isAdmin} />} />
          </Routes>
        </main>
        
        {/* Mobile Nav */}
        {user && (
          <div className="md:hidden fixed bottom-0 left-0 right-0 border-t border-white/10 bg-black/90 backdrop-blur-md z-50">
            <div className="flex justify-around p-3">
              <Link to="/dashboard" className="flex flex-col items-center text-xs text-gray-400 hover:text-primary"><LayoutDashboard size={20}/>Dash</Link>
              <Link to="/wallet" className="flex flex-col items-center text-xs text-gray-400 hover:text-primary"><WalletIcon size={20}/>Wallet</Link>
              <Link to="/withdraw" className="flex flex-col items-center text-xs text-gray-400 hover:text-primary"><ArrowDownToLine size={20}/>Withdraw</Link>
              <Link to="/referral" className="flex flex-col items-center text-xs text-gray-400 hover:text-primary"><Users size={20}/>Refer</Link>
              <button onClick={() => window.dispatchEvent(new Event('local-logout'))} className="flex flex-col items-center text-xs text-gray-400 hover:text-white"><LogOut size={20}/>Logout</button>
            </div>
          </div>
        )}
      </div>
    </Router>
  );
}
