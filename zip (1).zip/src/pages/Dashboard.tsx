import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { doc, onSnapshot, updateDoc, collection, addDoc, increment } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import SpinWheel from "@/src/components/SpinWheel";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Wallet } from "lucide-react";
import { motion } from "motion/react";

export default function Dashboard({ user }: { user: any }) {
  const navigate = useNavigate();
  const [walletBalance, setWalletBalance] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<{ winAmount: number, betAmount: number } | null>(null);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const unsubscribe = onSnapshot(doc(db, "users", user.uid), (doc) => {
      if (doc.exists()) {
        setWalletBalance(doc.data().walletBalance || 0);
      }
    });

    return () => unsubscribe();
  }, [user, navigate]);

  const handleSpinComplete = async (winAmount: number, betAmount: number) => {
    if (!user) return;
    
    setSpinResult({ winAmount, betAmount });

    try {
      const userRef = doc(db, "users", user.uid);
      
      // Update wallet balance (deduct betAmount, add winAmount)
      const netChange = winAmount - betAmount;
      await updateDoc(userRef, {
        walletBalance: increment(netChange)
      });

      // Record spin
      await addDoc(collection(db, "spins"), {
        userId: user.uid,
        cost: betAmount,
        winAmount,
        createdAt: new Date().toISOString()
      });

      // Record transactions
      await addDoc(collection(db, "transactions"), {
        userId: user.uid,
        amount: betAmount,
        type: "spin_deduction",
        status: "completed",
        createdAt: new Date().toISOString()
      });

      if (winAmount > 0) {
        await addDoc(collection(db, "transactions"), {
          userId: user.uid,
          amount: winAmount,
          type: "spin_win",
          status: "completed",
          createdAt: new Date().toISOString()
        });
      }

    } catch (error) {
      console.error("Error updating after spin:", error);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="md:col-span-1 bg-gradient-to-br from-black/60 to-purple-900/20 border-purple-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-gray-400 text-sm font-medium flex items-center gap-2">
              <Wallet className="h-4 w-4" /> Wallet Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <motion.div 
              key={walletBalance}
              initial={{ scale: 1.2, color: "#FFD700" }}
              animate={{ scale: 1, color: "#FFFFFF" }}
              className="text-4xl font-bold"
            >
              ₹{walletBalance.toFixed(2)}
            </motion.div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col items-center justify-center py-8">
        <h2 className="text-3xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-primary to-highlight-blue">
          Spin the Wheel of Fortune
        </h2>
        <SpinWheel 
          onSpinComplete={handleSpinComplete} 
          isSpinning={isSpinning} 
          setIsSpinning={(val) => {
            setIsSpinning(val);
            if (val) setSpinResult(null); // Clear result when starting a new spin
          }}
          walletBalance={walletBalance}
        />
      </div>

      {/* Result Popup */}
      {spinResult && !isSpinning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`max-w-sm w-full p-8 rounded-2xl border text-center ${
              spinResult.winAmount > 0 
                ? 'bg-gradient-to-b from-purple-900/80 to-black border-primary shadow-[0_0_50px_rgba(255,215,0,0.3)]' 
                : 'bg-gradient-to-b from-gray-900 to-black border-gray-700'
            }`}
          >
            <h3 className={`text-3xl font-bold mb-4 ${spinResult.winAmount > 0 ? 'text-primary' : 'text-gray-400'}`}>
              {spinResult.winAmount > 0 ? 'JACKPOT!' : 'Better Luck Next Time!'}
            </h3>
            
            <div className="text-5xl font-black mb-6 text-white">
              {spinResult.winAmount > 0 ? `+₹${spinResult.winAmount}` : '₹0'}
            </div>
            
            <p className="text-gray-400 mb-8">
              {spinResult.winAmount > 0 
                ? `You won ${spinResult.winAmount / spinResult.betAmount}x your bet of ₹${spinResult.betAmount}!` 
                : `You lost your bet of ₹${spinResult.betAmount}.`}
            </p>
            
            <Button 
              variant={spinResult.winAmount > 0 ? "neon" : "outline"} 
              className="w-full"
              onClick={() => setSpinResult(null)}
            >
              {spinResult.winAmount > 0 ? 'Awesome!' : 'Try Again'}
            </Button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
