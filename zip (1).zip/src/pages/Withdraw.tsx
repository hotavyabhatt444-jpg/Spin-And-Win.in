import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { doc, onSnapshot, collection, addDoc, updateDoc, increment, query, where, orderBy } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";

export default function Withdraw({ user }: { user: any }) {
  const navigate = useNavigate();
  const [walletBalance, setWalletBalance] = useState(0);
  const [amount, setAmount] = useState("");
  const [upiId, setUpiId] = useState("");
  const [loading, setLoading] = useState(false);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const unsubscribeUser = onSnapshot(doc(db, "users", user.uid), (doc) => {
      if (doc.exists()) {
        setWalletBalance(doc.data().walletBalance || 0);
      }
    });

    const q = query(
      collection(db, "withdrawals"),
      where("userId", "==", user.uid),
      orderBy("createdAt", "desc")
    );

    const unsubscribeW = onSnapshot(q, (snapshot) => {
      const w: any[] = [];
      snapshot.forEach((doc) => {
        w.push({ id: doc.id, ...doc.data() });
      });
      setWithdrawals(w);
    });

    return () => {
      unsubscribeUser();
      unsubscribeW();
    };
  }, [user, navigate]);

  const handleWithdraw = async () => {
    const numAmount = parseInt(amount);
    if (isNaN(numAmount) || numAmount < 100) {
      alert("Minimum withdrawal is ₹100");
      return;
    }
    if (numAmount > walletBalance) {
      alert("Insufficient balance");
      return;
    }
    if (!upiId.includes("@")) {
      alert("Please enter a valid UPI ID");
      return;
    }

    setLoading(true);
    try {
      // Deduct from wallet immediately
      const userRef = doc(db, "users", user.uid);
      await updateDoc(userRef, {
        walletBalance: increment(-numAmount)
      });

      // Create withdrawal request
      await addDoc(collection(db, "withdrawals"), {
        userId: user.uid,
        amount: numAmount,
        upiId,
        status: "pending",
        createdAt: new Date().toISOString()
      });

      // Record transaction
      await addDoc(collection(db, "transactions"), {
        userId: user.uid,
        amount: numAmount,
        type: "withdraw",
        status: "pending",
        createdAt: new Date().toISOString()
      });

      setAmount("");
      setUpiId("");
      alert("Withdrawal request submitted successfully!");
    } catch (error) {
      console.error("Withdrawal failed", error);
      alert("Failed to submit request.");
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Withdraw Winnings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 mb-1 block">Available Balance</label>
              <div className="text-3xl font-bold text-primary">₹{walletBalance.toFixed(2)}</div>
            </div>
            
            <div>
              <label className="text-sm text-gray-400 mb-1 block">Amount (Min ₹100)</label>
              <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
              />
            </div>

            <div>
              <label className="text-sm text-gray-400 mb-1 block">UPI ID</label>
              <Input 
                type="text" 
                value={upiId} 
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="example@upi"
              />
            </div>

            <Button 
              variant="neon" 
              className="w-full" 
              onClick={handleWithdraw}
              disabled={loading || walletBalance < 100}
            >
              {loading ? "Processing..." : "Withdraw Now"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Withdrawal History</CardTitle>
          </CardHeader>
          <CardContent>
            {withdrawals.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No withdrawals yet.</div>
            ) : (
              <div className="space-y-4">
                {withdrawals.map(w => (
                  <div key={w.id} className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                    <div>
                      <p className="font-medium">₹{w.amount}</p>
                      <p className="text-xs text-gray-400">{w.upiId}</p>
                      <p className="text-xs text-gray-500">{new Date(w.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        w.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                        w.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                        'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {w.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
